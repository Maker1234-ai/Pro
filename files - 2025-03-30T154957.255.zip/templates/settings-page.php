<div class="wrap wp-management-wrap">
    <div class="wp-management-header">
        <h1>Settings</h1>
    </div>
    
    <div class="wp-management-form">
        <form method="post" action="options.php">
            <?php settings_fields('wp_management_settings'); ?>
            <?php do_settings_sections('wp_management_settings'); ?>
            
            <div class="form-group">
                <label for="max_jobs_per_minute">Maximum Jobs Per Minute</label>
                <input type="number" id="max_jobs_per_minute" name="wp_management_max_jobs_per_minute" 
                       value="<?php echo esc_attr(get_option('wp_management_max_jobs_per_minute', '1000')); ?>" min="1" max="1000">
            </div>

            <?php submit_button('Save Settings', 'wp-management-button'); ?>
        </form>
    </div>
</div>