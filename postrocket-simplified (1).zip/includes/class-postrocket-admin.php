<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The admin-specific functionality of the plugin.
 */
class PostRocket_Admin {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Empty constructor - hooks will be added by the loader
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style( 'postrocket-admin', POSTROCKET_PLUGIN_URL . 'assets/css/postrocket-admin.css', array(), POSTROCKET_VERSION, 'all' );
        wp_enqueue_style( 'postrocket-icon', POSTROCKET_PLUGIN_URL . 'assets/css/postrocket-icon.css', array(), POSTROCKET_VERSION, 'all' );
        wp_enqueue_style( 'postrocket-notifications', POSTROCKET_PLUGIN_URL . 'assets/css/postrocket-notifications.css', array(), POSTROCKET_VERSION, 'all' );
        wp_enqueue_style( 'postrocket-api-popup', POSTROCKET_PLUGIN_URL . 'assets/css/postrocket-api-popup.css', array(), POSTROCKET_VERSION, 'all' );
        wp_enqueue_style( 'postrocket-job-popup', POSTROCKET_PLUGIN_URL . 'assets/css/postrocket-job-popup.css', array(), POSTROCKET_VERSION, 'all' );
        wp_enqueue_style( 'dashicons' );
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script( 'postrocket-admin', POSTROCKET_PLUGIN_URL . 'assets/js/postrocket-admin.js', array( 'jquery' ), POSTROCKET_VERSION, false );
        wp_enqueue_script( 'postrocket-api-popup', POSTROCKET_PLUGIN_URL . 'assets/js/postrocket-api-popup.js', array( 'jquery' ), POSTROCKET_VERSION, false );
        wp_enqueue_script( 'postrocket-job-popup', POSTROCKET_PLUGIN_URL . 'assets/js/postrocket-job-popup.js', array( 'jquery' ), POSTROCKET_VERSION, false );
        
        // Localize the script with data for AJAX
        wp_localize_script( 'postrocket-admin', 'postrocket_ajax', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'postrocket_nonce' ),
            'admin_url' => admin_url(),
        ) );
    }

    /**
     * Add custom admin body class to hide WordPress notices on plugin pages.
     * This is hooked to admin_body_class in the loader.
     *
     * @since    1.0.0
     * @param    string   $classes    Admin body classes.
     * @return   string   Modified admin body classes.
     */
    public function add_admin_body_class($classes) {
        if (!function_exists('get_current_screen')) {
            return $classes;
        }
        
        $screen = get_current_screen();
        
        // Check if we're on a PostRocket admin page and screen object exists
        if (is_object($screen) && isset($screen->id) && strpos($screen->id, 'postrocket') !== false) {
            $classes .= ' postrocket-admin-page';
        }
        
        return $classes;
    }

    /**
     * Add menu items to the admin menu.
     *
     * @since    1.0.0
     */
    public function add_plugin_admin_menu() {
        // Main menu item
        add_menu_page(
            __( 'PostRocket', 'postrocket' ),
            __( 'PostRocket', 'postrocket' ),
            'manage_options',
            'postrocket-job-manager',
            array( $this, 'display_job_manager_page' ),
            POSTROCKET_PLUGIN_URL . 'assets/images/rocket-icon.svg',
            26
        );

        // Job Manager submenu
        add_submenu_page(
            'postrocket-job-manager',
            __( 'Job Manager', 'postrocket' ),
            __( 'Job Manager', 'postrocket' ),
            'manage_options',
            'postrocket-job-manager',
            array( $this, 'display_job_manager_page' )
        );
    }

    /**
     * Display the dashboard page.
     *
     * @since    1.0.0
     */
    public function display_dashboard_page() {
        include_once POSTROCKET_PLUGIN_DIR . 'includes/partials/postrocket-admin-dashboard.php';
    }

    /**
     * Display the job manager page.
     *
     * @since    1.0.0
     */
    public function display_job_manager_page() {
        include_once POSTROCKET_PLUGIN_DIR . 'includes/partials/postrocket-admin-job-manager.php';
    }
    
    // Bulk operations removed as requested
    
    // Location manager removed as requested
    
    // Help and support removed as requested
    
    /**
     * AJAX handler for saving location list.
     *
     * @since    1.0.0
     */
    public function ajax_save_location_list() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Sanitize input data
        $name = isset( $_POST['location_list_name'] ) ? sanitize_text_field( $_POST['location_list_name'] ) : '';
        $locations = isset( $_POST['locations'] ) ? sanitize_textarea_field( $_POST['locations'] ) : '';

        // Get location manager instance
        $location_manager = new PostRocket_Location_Manager();
        
        // Process location list saving
        $result = $location_manager->save_location_list( $name, $locations );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message' => $result['message'],
                'key' => $result['key'],
                'list' => $result['list'],
            ) );
        }
    }
    
    /**
     * AJAX handler for deleting location list.
     *
     * @since    1.0.0
     */
    public function ajax_delete_location_list() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Sanitize input data
        $key = isset( $_POST['key'] ) ? sanitize_text_field( $_POST['key'] ) : '';

        // Get location manager instance
        $location_manager = new PostRocket_Location_Manager();
        
        // Process location list deletion
        $result = $location_manager->delete_location_list( $key );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array( 'message' => $result['message'] ) );
        }
    }
    
    /**
     * AJAX handler for deleting all duplicate jobs.
     *
     * @since    1.0.0
     */
    public function ajax_delete_duplicate_jobs() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Get bulk manager instance
        $bulk_manager = new PostRocket_Bulk_Manager();
        
        // Process job deletion
        $result = $bulk_manager->delete_all_duplicate_jobs();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message' => sprintf( __( 'Successfully deleted %d duplicate jobs.', 'postrocket' ), $result ),
                'count' => $result,
            ) );
        }
    }
    
    /**
     * AJAX handler for deleting all expired jobs.
     *
     * @since    1.0.0
     */
    public function ajax_delete_expired_jobs() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Get bulk manager instance
        $bulk_manager = new PostRocket_Bulk_Manager();
        
        // Process job deletion
        $result = $bulk_manager->delete_all_expired_jobs();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message' => sprintf( __( 'Successfully deleted %d expired jobs.', 'postrocket' ), $result ),
                'count' => $result,
            ) );
        }
    }
    
    /**
     * AJAX handler for deleting all jobs.
     *
     * @since    1.0.0
     */
    public function ajax_delete_all_jobs() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Get bulk manager instance
        $bulk_manager = new PostRocket_Bulk_Manager();
        
        // Process job deletion
        $result = $bulk_manager->delete_all_jobs();

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array(
                'message' => sprintf( __( 'Successfully deleted %d jobs.', 'postrocket' ), $result ),
                'count' => $result,
            ) );
        }
    }

    /**
     * AJAX handler for duplicating jobs.
     *
     * @since    1.0.0
     */
    public function ajax_duplicate_jobs() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Sanitize input data
        $job_id = isset( $_POST['job_id'] ) ? intval( $_POST['job_id'] ) : 0;
        $company_id = isset( $_POST['company_id'] ) ? intval( $_POST['company_id'] ) : 0;
        $locations = isset( $_POST['locations'] ) ? sanitize_textarea_field( $_POST['locations'] ) : '';
        $mode = isset( $_POST['mode'] ) ? sanitize_text_field( $_POST['mode'] ) : 'manual';
        $location_list_key = isset( $_POST['location_list_key'] ) ? sanitize_text_field( $_POST['location_list_key'] ) : '';

        // Validate input data
        if ( empty( $job_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Please select a base job.', 'postrocket' ) ) );
        }

        // If auto mode, get locations from saved list
        if ( $mode === 'auto' && !empty( $location_list_key ) ) {
            $location_manager = new PostRocket_Location_Manager();
            $location_list = $location_manager->get_location_list( $location_list_key );
            
            if ( $location_list ) {
                $locations = implode( ', ', $location_list['locations'] );
            }
        }

        if ( empty( $locations ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter at least one location.', 'postrocket' ) ) );
        }

        // Get job duplicator instance
        $job_duplicator = new PostRocket_Job_Duplicator();
        
        // Process job duplication
        $result = $job_duplicator->duplicate_jobs( $job_id, $company_id, $locations );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            // Get detailed information about created jobs for the popup
            $jobs_data = array();
            foreach ( $result as $new_job_id ) {
                $job = get_post( $new_job_id );
                if ( $job ) {
                    $location = get_post_meta( $new_job_id, '_job_location', true );
                    $jobs_data[] = array(
                        'id'       => $new_job_id,
                        'title'    => $job->post_title,
                        'location' => $location,
                        'edit_url' => admin_url( 'post.php?post=' . $new_job_id . '&action=edit' ),
                        'view_url' => get_permalink( $new_job_id ),
                    );
                }
            }
            
            wp_send_json_success( array(
                'message' => sprintf( __( 'Successfully duplicated job to %d locations.', 'postrocket' ), count( $result ) ),
                'created_jobs' => $result,
                'jobs' => $jobs_data,
            ) );
        }
    }

    /**
     * AJAX handler for saving settings.
     *
     * @since    1.0.0
     */
    public function ajax_save_settings() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Sanitize input data
        $hide_duplicates = isset( $_POST['hide_duplicates'] ) ? sanitize_text_field( $_POST['hide_duplicates'] ) : 'no';
        $noindex_duplicates = isset( $_POST['noindex_duplicates'] ) ? sanitize_text_field( $_POST['noindex_duplicates'] ) : 'no';

        // Save settings
        update_option( 'postrocket_hide_duplicates', $hide_duplicates );
        update_option( 'postrocket_noindex_duplicates', $noindex_duplicates );

        wp_send_json_success( array( 'message' => __( 'Settings saved successfully.', 'postrocket' ) ) );
    }

    /**
     * AJAX handler for saving API key.
     *
     * @since    1.0.0
     */
    public function ajax_save_api_key() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Sanitize input data
        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';

        // Get API instance
        $api = new PostRocket_API();
        
        // Encrypt and save API key
        $result = $api->save_api_key( $api_key );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        } else {
            wp_send_json_success( array( 'message' => __( 'API key saved successfully.', 'postrocket' ) ) );
        }
    }
    
    /**
     * AJAX handler for verifying API key.
     *
     * @since    1.0.0
     */
    public function ajax_verify_api_key() {
        // Check nonce for security
        check_ajax_referer( 'postrocket_nonce', 'nonce' );

        // Check user permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'postrocket' ) ) );
        }

        // Get API instance
        $api = new PostRocket_API();
        
        // Verify API key
        $result = $api->verify_api_key();

        if ( $result['status'] === 'error' ) {
            wp_send_json_error( array( 'message' => $result['message'] ) );
        } else {
            wp_send_json_success( array( 'message' => $result['message'] ) );
        }
    }

    /**
     * Add noindex meta tag to duplicated jobs.
     *
     * @since    1.0.0
     */
    public function add_noindex_meta() {
        global $post;
        
        // Check if we're on a single job post
        if ( ! is_singular( 'job_listing' ) || ! is_object( $post ) ) {
            return;
        }
        
        // Check if noindex is enabled for duplicates
        $noindex_duplicates = get_option( 'postrocket_noindex_duplicates', 'no' );
        if ( $noindex_duplicates !== 'yes' ) {
            return;
        }
        
        // Check if this is a duplicated job
        $is_duplicate = get_post_meta( $post->ID, '_postrocket_is_duplicate', true );
        if ( $is_duplicate !== 'yes' ) {
            return;
        }
        
        // Add noindex meta tag
        echo '<meta name="robots" content="noindex,nofollow" />';
    }
    
    /**
     * Filter job listings to hide duplicates.
     *
     * @since    1.0.0
     * @param    WP_Query   $query    The WP_Query instance.
     */
    public function filter_job_listings( $query ) {
        // Check if hide duplicates is enabled
        $hide_duplicates = get_option( 'postrocket_hide_duplicates', 'no' );
        if ( $hide_duplicates !== 'yes' ) {
            return;
        }
        
        // Only modify job listing queries on frontend
        if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive( 'job_listing' ) ) {
            return;
        }
        
        // Get current meta query
        $meta_query = $query->get( 'meta_query' );
        if ( ! is_array( $meta_query ) ) {
            $meta_query = array();
        }
        
        // Add meta query to exclude duplicates
        $meta_query[] = array(
            'relation' => 'OR',
            array(
                'key'     => '_postrocket_is_duplicate',
                'compare' => 'NOT EXISTS',
            ),
            array(
                'key'     => '_postrocket_is_duplicate',
                'value'   => 'yes',
                'compare' => '!=',
            ),
        );
        
        $query->set( 'meta_query', $meta_query );
    }
}
