<?php
/**
 * The job duplicator functionality of the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The job duplicator functionality of the plugin.
 */
class PostRocket_Job_Duplicator {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
    }

    /**
     * Duplicate jobs to multiple locations.
     *
     * @since    1.0.0
     * @param    int      $job_id       The ID of the base job.
     * @param    int      $company_id   The ID of the company (optional).
     * @param    string   $locations    Comma-separated list of locations.
     * @return   array|WP_Error         Array of created job IDs or WP_Error on failure.
     */
    public function duplicate_jobs( $job_id, $company_id, $locations ) {
        // Input validation and sanitization
        $job_id = absint($job_id);
        $company_id = absint($company_id);
        $locations = sanitize_textarea_field($locations);
        
        // Check if API key is valid
        $api = new PostRocket_API();
        if ( ! $api->validate_api_key() ) {
            return new WP_Error( 'invalid_api_key', __( 'Valid API key is required to use job duplication feature.', 'postrocket' ) );
        }
        
        // Check if job exists
        $job = get_post( $job_id );
        if ( ! $job || $job->post_type !== 'job_listing' ) {
            return new WP_Error( 'invalid_job', __( 'The selected job does not exist or is not a valid job listing.', 'postrocket' ) );
        }

        // Parse locations
        $location_array = array_map( 'trim', explode( ',', $locations ) );
        $location_array = array_filter( $location_array );
        
        // Remove duplicates and empty values
        $location_array = array_unique($location_array);

        if ( empty( $location_array ) ) {
            return new WP_Error( 'no_locations', __( 'No valid locations provided.', 'postrocket' ) );
        }
        
        // Check if location count exceeds limit
        if ( count( $location_array ) > 50 ) {
            return new WP_Error( 'too_many_locations', __( 'You cannot add more than 50 locations to duplicate a job.', 'postrocket' ) );
        }

        $created_jobs = array();
        $original_company = '';

        // Get original company if no company is selected
        if ( empty( $company_id ) ) {
            $original_company = get_post_meta( $job_id, '_company_name', true );
        } else {
            // Get company name from MAS Companies
            $company = get_post( $company_id );
            if ( $company && $company->post_type === 'company' ) {
                $original_company = $company->post_title;
            }
        }

        // Get all post meta
        $post_meta = get_post_meta( $job_id );

        // Get all taxonomies
        $taxonomies = get_object_taxonomies( 'job_listing' );
        $term_data = array();

        foreach ( $taxonomies as $taxonomy ) {
            $terms = wp_get_post_terms( $job_id, $taxonomy, array( 'fields' => 'ids' ) );
            if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                $term_data[ $taxonomy ] = $terms;
            }
        }

        // Loop through locations and create jobs
        foreach ( $location_array as $location ) {
            // Sanitize location
            $location = sanitize_text_field($location);
            
            // Skip if empty after sanitization
            if (empty($location)) {
                continue;
            }
            
            // Create a unique hash for this job+location combination
            $hash = md5( $job_id . '_' . sanitize_title( $location ) );
            
            // Check if this job+location already exists (using transient cache)
            $duplicate_check = get_transient( 'postrocket_duplicate_' . $hash );
            if ( $duplicate_check ) {
                continue; // Skip this location if already duplicated recently
            }

            // Set transient to prevent duplicate creation (expires after 1 hour)
            set_transient( 'postrocket_duplicate_' . $hash, true, HOUR_IN_SECONDS );

            // Create new job post
            $new_job_id = $this->create_duplicate_job( $job, $location, $original_company, $post_meta, $term_data, $company_id );
            
            if ( ! is_wp_error( $new_job_id ) ) {
                $created_jobs[] = $new_job_id;
            }
            
            // Small delay to prevent server overload but still maintain good speed
            usleep(25000); // 25ms delay - faster than before (was 50ms)
        }

        if ( empty( $created_jobs ) ) {
            return new WP_Error( 'duplication_failed', __( 'Failed to create any job duplicates.', 'postrocket' ) );
        }

        return $created_jobs;
    }

    /**
     * Create a duplicate job for a specific location.
     *
     * @since    1.0.0
     * @param    WP_Post   $job              The original job post.
     * @param    string    $location         The location for the new job.
     * @param    string    $company_name     The company name.
     * @param    array     $post_meta        The original job post meta.
     * @param    array     $term_data        The original job taxonomy terms.
     * @param    int       $company_id       The company ID (optional).
     * @return   int|WP_Error                The new job ID or WP_Error on failure.
     */
    private function create_duplicate_job( $job, $location, $company_name, $post_meta, $term_data, $company_id ) {
        // Get global count for this job title across all locations
        global $wpdb;
        $global_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                WHERE p.post_type = 'job_listing'
                AND p.post_status = 'publish'
                AND p.post_title LIKE %s",
                '%' . $wpdb->esc_like($job->post_title) . '%'
            )
        );
        
        // Create new job title with location
        // Always add the location name
        $new_title = $job->post_title . ' - ' . $location;
        
        // Add counter only if there are multiple jobs with the same title and location
        // We need to check if there are already jobs with this exact title pattern
        $exact_title_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                WHERE p.post_type = 'job_listing'
                AND p.post_status = 'publish'
                AND p.post_title = %s",
                $job->post_title . ' - ' . $location
            )
        );
        
        if ($exact_title_count > 0) {
            $new_title .= ' (' . $global_count . ')';
        }

        // Create new job post
        $new_job_args = array(
            'post_title'     => $new_title,
            'post_content'   => $job->post_content,
            'post_excerpt'   => $job->post_excerpt,
            'post_status'    => 'publish',
            'post_type'      => 'job_listing',
            'post_author'    => $job->post_author,
            'comment_status' => $job->comment_status,
            'ping_status'    => $job->ping_status,
        );

        // Insert the new job post
        $new_job_id = wp_insert_post( $new_job_args );

        if ( is_wp_error( $new_job_id ) ) {
            return $new_job_id;
        }

        // Copy all post meta
        foreach ( $post_meta as $meta_key => $meta_values ) {
            // Skip internal WordPress meta
            if ( '_edit_lock' === $meta_key || '_edit_last' === $meta_key ) {
                continue;
            }

            // Handle location meta
            if ( '_job_location' === $meta_key ) {
                update_post_meta( $new_job_id, $meta_key, $location );
                continue;
            }

            // Handle company meta
            if ( '_company_name' === $meta_key && ! empty( $company_name ) ) {
                update_post_meta( $new_job_id, $meta_key, $company_name );
                continue;
            }

            // Handle company ID meta for MAS Companies
            if ( '_company_id' === $meta_key && ! empty( $company_id ) ) {
                update_post_meta( $new_job_id, $meta_key, $company_id );
                continue;
            }

            // Copy all other meta
            foreach ( $meta_values as $meta_value ) {
                $meta_value = maybe_unserialize( $meta_value );
                update_post_meta( $new_job_id, $meta_key, $meta_value );
            }
        }

        // Add duplicated flag
        update_post_meta( $new_job_id, '_postrocket_duplicated', '1' );
        update_post_meta( $new_job_id, '_postrocket_original_job_id', $job->ID );

        // Set taxonomy terms
        foreach ( $term_data as $taxonomy => $term_ids ) {
            wp_set_object_terms( $new_job_id, $term_ids, $taxonomy );
        }

        return $new_job_id;
    }

    /**
     * Get recent jobs.
     *
     * @since    1.0.0
     * @param    int      $limit    The number of jobs to retrieve.
     * @return   array              Array of job posts.
     */
    public function get_recent_jobs( $limit = 5 ) {
        $args = array(
            'post_type'      => 'job_listing',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        $query = new WP_Query( $args );
        return $query->posts;
    }

    /**
     * Get job count.
     *
     * @since    1.0.0
     * @return   int    The number of job posts.
     */
    public function get_job_count() {
        $counts = wp_count_posts( 'job_listing' );
        return $counts->publish;
    }

    /**
     * Get total jobs across all stored locations.
     *
     * @since    1.0.0
     * @return   int    The total number of jobs across all stored locations.
     */
    public function get_total_jobs_across_locations() {
        // Get location manager instance
        $location_manager = new PostRocket_Location_Manager();
        
        // Get all locations from all lists
        $all_locations = $location_manager->get_all_locations();
        
        if (empty($all_locations)) {
            return $this->get_job_count();
        }
        
        // Count jobs for each location
        global $wpdb;
        $location_placeholders = implode(',', array_fill(0, count($all_locations), '%s'));
        
        $query = $wpdb->prepare(
            "SELECT COUNT(DISTINCT p.ID) as count
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'job_listing'
            AND p.post_status = 'publish'
            AND pm.meta_key = '_job_location'
            AND pm.meta_value IN ($location_placeholders)",
            $all_locations
        );
        
        $count = $wpdb->get_var($query);
        
        return $count ? $count : 0;
    }

    /**
     * Get active job count.
     *
     * @since    1.0.0
     * @return   int    The number of active job posts.
     */
    public function get_active_job_count() {
        $args = array(
            'post_type'      => 'job_listing',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'     => '_job_expires',
                    'value'   => date( 'Y-m-d' ),
                    'compare' => '>=',
                    'type'    => 'DATE',
                ),
            ),
        );

        $query = new WP_Query( $args );
        return $query->found_posts;
    }

    /**
     * Get location distribution.
     *
     * @since    1.0.0
     * @return   array    Array of locations with counts and percentages.
     */
    public function get_location_distribution() {
        global $wpdb;

        $query = "
            SELECT meta_value as location, COUNT(*) as count
            FROM {$wpdb->postmeta} pm
            JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = '_job_location'
            AND p.post_type = 'job_listing'
            AND p.post_status = 'publish'
            AND meta_value != ''
            GROUP BY meta_value
            ORDER BY count DESC
            LIMIT 10
        ";

        $results = $wpdb->get_results( $query );
        $total = 0;
        $locations = array();

        // Calculate total
        foreach ( $results as $result ) {
            $total += $result->count;
        }

        // Calculate percentages
        foreach ( $results as $result ) {
            $percentage = ( $total > 0 ) ? round( ( $result->count / $total ) * 100, 1 ) : 0;
            $locations[] = array(
                'location'   => $result->location,
                'count'      => $result->count,
                'percentage' => $percentage,
            );
        }

        return $locations;
    }

    /**
     * Get company count.
     *
     * @since    1.0.0
     * @return   int    The number of companies.
     */
    public function get_company_count() {
        // Check if MAS Companies is active
        if ( post_type_exists( 'company' ) ) {
            $counts = wp_count_posts( 'company' );
            return $counts->publish;
        }

        // Fallback to counting unique company names
        global $wpdb;
        $query = "
            SELECT COUNT(DISTINCT meta_value) as count
            FROM {$wpdb->postmeta}
            WHERE meta_key = '_company_name'
        ";
        return $wpdb->get_var( $query );
    }

    /**
     * Get all jobs for dropdown.
     *
     * @since    1.0.0
     * @param    int      $limit    The number of jobs to retrieve.
     * @return   array              Array of jobs with ID and title.
     */
    public function get_jobs_for_dropdown( $limit = 2000 ) {
        $args = array(
            'post_type'      => 'job_listing',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => false,
            'cache_results'  => false,
        );

        $query = new WP_Query( $args );
        $jobs = array();

        foreach ( $query->posts as $job ) {
            $location = get_post_meta( $job->ID, '_job_location', true );
            $location_text = !empty($location) ? ' - ' . $location : '';
            
            $jobs[] = array(
                'id'    => $job->ID,
                'title' => $job->post_title . $location_text,
            );
        }

        return $jobs;
    }

    /**
     * Get all companies for dropdown.
     *
     * @since    1.0.0
     * @return   array    Array of companies with ID and name.
     */
    public function get_companies_for_dropdown() {
        $companies = array();

        // Check if MAS Companies is active
        if ( post_type_exists( 'company' ) ) {
            $args = array(
                'post_type'      => 'company',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            );

            $query = new WP_Query( $args );

            foreach ( $query->posts as $company ) {
                $companies[] = array(
                    'id'   => $company->ID,
                    'name' => $company->post_title,
                );
            }
        }

        return $companies;
    }
}
