<?php
/**
 * Provide a admin area view for the plugin dashboard page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Get job duplicator instance
$job_duplicator = new PostRocket_Job_Duplicator();

// Get statistics
$total_jobs = $job_duplicator->get_job_count();
$active_jobs = $job_duplicator->get_active_job_count();
$total_companies = $job_duplicator->get_company_count();
$location_distribution = $job_duplicator->get_location_distribution();
$total_locations = count( $location_distribution );
$recent_jobs = $job_duplicator->get_recent_jobs( 5 );
?>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    <div class="postrocket-dashboard">
        <!-- Statistics Cards -->
        <div class="postrocket-stats-cards">
            <div class="postrocket-card">
                <div class="postrocket-card-icon">
                    <span class="dashicons dashicons-portfolio"></span>
                </div>
                <div class="postrocket-card-content">
                    <h3><?php echo esc_html( $total_jobs ); ?></h3>
                    <p><?php esc_html_e( 'Total Jobs', 'postrocket' ); ?></p>
                </div>
            </div>
            
            <div class="postrocket-card">
                <div class="postrocket-card-icon">
                    <span class="dashicons dashicons-networking"></span>
                </div>
                <div class="postrocket-card-content">
                    <h3><?php echo esc_html( $job_duplicator->get_total_jobs_across_locations() ); ?></h3>
                    <p><?php esc_html_e( 'Jobs Across All Locations', 'postrocket' ); ?></p>
                </div>
            </div>
            
            <div class="postrocket-card">
                <div class="postrocket-card-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="postrocket-card-content">
                    <h3><?php echo esc_html( $active_jobs ); ?></h3>
                    <p><?php esc_html_e( 'Active Jobs', 'postrocket' ); ?></p>
                </div>
            </div>
            
            <div class="postrocket-card">
                <div class="postrocket-card-icon">
                    <span class="dashicons dashicons-location"></span>
                </div>
                <div class="postrocket-card-content">
                    <h3><?php echo esc_html( $total_locations ); ?></h3>
                    <p><?php esc_html_e( 'Total Locations', 'postrocket' ); ?></p>
                </div>
            </div>
            
            <div class="postrocket-card">
                <div class="postrocket-card-icon">
                    <span class="dashicons dashicons-building"></span>
                </div>
                <div class="postrocket-card-content">
                    <h3><?php echo esc_html( $total_companies ); ?></h3>
                    <p><?php esc_html_e( 'Total Companies', 'postrocket' ); ?></p>
                </div>
            </div>
        </div>
        
        <!-- Two Column Layout -->
        <div class="postrocket-dashboard-columns">
            <!-- Recent Jobs -->
            <div class="postrocket-column">
                <div class="postrocket-card">
                    <div class="postrocket-card-header">
                        <h2><?php esc_html_e( 'Recent Jobs', 'postrocket' ); ?></h2>
                    </div>
                    <div class="postrocket-card-content">
                        <?php if ( ! empty( $recent_jobs ) ) : ?>
                            <table class="postrocket-table">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e( 'Job Title', 'postrocket' ); ?></th>
                                        <th><?php esc_html_e( 'Location', 'postrocket' ); ?></th>
                                        <th><?php esc_html_e( 'Date', 'postrocket' ); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ( $recent_jobs as $job ) : ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo esc_url( get_edit_post_link( $job->ID ) ); ?>">
                                                    <?php echo esc_html( $job->post_title ); ?>
                                                </a>
                                            </td>
                                            <td>
                                                <?php echo esc_html( get_post_meta( $job->ID, '_job_location', true ) ); ?>
                                            </td>
                                            <td>
                                                <?php echo esc_html( get_the_date( '', $job->ID ) ); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else : ?>
                            <p><?php esc_html_e( 'No jobs found.', 'postrocket' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Location Distribution -->
            <div class="postrocket-column">
                <div class="postrocket-card">
                    <div class="postrocket-card-header">
                        <h2><?php esc_html_e( 'Location Distribution', 'postrocket' ); ?></h2>
                    </div>
                    <div class="postrocket-card-content">
                        <?php if ( ! empty( $location_distribution ) ) : ?>
                            <div class="postrocket-chart-container">
                                <canvas id="locationDistributionChart"></canvas>
                            </div>
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    const ctx = document.getElementById('locationDistributionChart').getContext('2d');
                                    
                                    // Extract data from PHP
                                    const locationData = <?php echo json_encode(array_slice($location_distribution, 0, 10)); ?>;
                                    const labels = locationData.map(item => item.location);
                                    const counts = locationData.map(item => item.count);
                                    const percentages = locationData.map(item => item.percentage);
                                    
                                    // Generate colors
                                    const backgroundColors = [
                                        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
                                        '#5a5c69', '#858796', '#6610f2', '#fd7e14', '#20c9a6'
                                    ];
                                    
                                    // Create chart
                                    const locationChart = new Chart(ctx, {
                                        type: 'pie',
                                        data: {
                                            labels: labels,
                                            datasets: [{
                                                data: counts,
                                                backgroundColor: backgroundColors,
                                                hoverBackgroundColor: backgroundColors.map(color => color + 'dd'),
                                                hoverBorderColor: "rgba(234, 236, 244, 1)",
                                            }]
                                        },
                                        options: {
                                            maintainAspectRatio: false,
                                            responsive: true,
                                            legend: {
                                                position: 'right',
                                                labels: {
                                                    fontColor: document.body.classList.contains('dark-theme') ? '#f1f1f1' : '#333'
                                                }
                                            },
                                            tooltips: {
                                                backgroundColor: "rgb(255,255,255)",
                                                bodyFontColor: "#858796",
                                                borderColor: '#dddfeb',
                                                borderWidth: 1,
                                                xPadding: 15,
                                                yPadding: 15,
                                                displayColors: false,
                                                caretPadding: 10,
                                                callbacks: {
                                                    label: function(tooltipItem, data) {
                                                        const label = data.labels[tooltipItem.index];
                                                        const value = data.datasets[0].data[tooltipItem.index];
                                                        const percentage = percentages[tooltipItem.index];
                                                        return label + ': ' + value + ' jobs (' + percentage + '%)';
                                                    }
                                                }
                                            }
                                        }
                                    });
                                    
                                    // Update chart colors when theme changes
                                    document.getElementById('theme-toggle').addEventListener('click', function() {
                                        setTimeout(function() {
                                            locationChart.options.legend.labels.fontColor = document.body.classList.contains('dark-theme') ? '#f1f1f1' : '#333';
                                            locationChart.update();
                                        }, 100);
                                    });
                                });
                            </script>
                            
                            <div class="postrocket-table-container" style="margin-top: 20px;">
                                <table class="postrocket-table">
                                    <thead>
                                        <tr>
                                            <th><?php esc_html_e( 'Location', 'postrocket' ); ?></th>
                                            <th><?php esc_html_e( 'Jobs', 'postrocket' ); ?></th>
                                            <th><?php esc_html_e( 'Percentage', 'postrocket' ); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ( array_slice( $location_distribution, 0, 10 ) as $location ) : ?>
                                            <tr>
                                                <td><?php echo esc_html( $location['location'] ); ?></td>
                                                <td><?php echo esc_html( $location['count'] ); ?></td>
                                                <td>
                                                    <div class="postrocket-progress-bar">
                                                        <div class="postrocket-progress" style="width: <?php echo esc_attr( $location['percentage'] ); ?>%"></div>
                                                    </div>
                                                    <span><?php echo esc_html( $location['percentage'] ); ?>%</span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else : ?>
                            <p><?php esc_html_e( 'No location data available.', 'postrocket' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
