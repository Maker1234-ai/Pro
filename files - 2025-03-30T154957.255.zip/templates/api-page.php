<div class="wrap wp-management-wrap">
    <div class="wp-management-header">
        <h1>API Key Management</h1>
    </div>
    
    <div class="wp-management-form">
        <div class="form-group">
            <label for="api-key">Enter API Key</label>
            <input type="text" id="api-key" name="api_key" value="<?php echo esc_attr(get_option('wp_management_api_key', '')); ?>" required>
        </div>

        <button id="verify-api-key" class="wp-management-button">Verify API Key</button>
    </div>
</div>