<div class="wrap">
    <h1><?php echo esc_html__('Settings', 'wp-management'); ?></h1>
    
    <div class="wp-management-container">
        <form method="post" action="options.php">
            <?php settings_fields('wp_management_settings'); ?>
            <?php do_settings_sections('wp_management_settings'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wp_management_max_jobs_per_minute">
                            <?php echo esc_html__('Max Jobs Per Minute', 'wp-management'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="wp_management_max_jobs_per_minute" 
                               name="wp_management_max_jobs_per_minute" 
                               value="<?php echo esc_attr($max_jobs); ?>" 
                               min="1" 
                               max="1000" 
                               class="regular-text">
                        <p class="description">
                            <?php echo esc_html__('Maximum number of jobs to process per minute (1-1000)', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="wp_management_crawling_delay">
                            <?php echo esc_html__('Crawling Delay', 'wp-management'); ?>
                        </label>
                    </th>
                    <td>
                        <input type="number" 
                               id="wp_management_crawling_delay" 
                               name="wp_management_crawling_delay" 
                               value="<?php echo esc_attr($crawling_delay); ?>" 
                               min="0" 
                               max="60" 
                               class="regular-text">
                        <p class="description">
                            <?php echo esc_html__('Delay between job creation to optimize Google crawling (seconds)', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
    </div>
</div>

<style>
.wp-management-container {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}
</style>