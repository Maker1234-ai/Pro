<?php
// Update the handle_api_verification method

public function handle_api_verification() {
    try {
        if (!check_ajax_referer('wp_management_nonce', 'nonce', false)) {
            throw new Exception('Invalid security token.');
        }
        
        if (!current_user_can('manage_options')) {
            throw new Exception('Insufficient permissions.');
        }
        
        $api_key = sanitize_text_field($_POST['api_key']);
        if (empty($api_key)) {
            throw new Exception('API key cannot be empty.');
        }
        
        $site_url = get_site_url();
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'wp_management_api_usage';
        
        // Check if API key is already in use
        $existing_site = $wpdb->get_var($wpdb->prepare(
            "SELECT site_url FROM $table_name WHERE api_key = %s AND site_url != %s",
            $api_key,
            $site_url
        ));
        
        if ($existing_site) {
            throw new Exception('This API key is already in use on another site.');
        }
        
        // Update or insert API usage record
        $result = $wpdb->replace(
            $table_name,
            array(
                'site_url' => $site_url,
                'api_key' => $api_key,
                'activation_date' => current_time('mysql', true)
            ),
            array('%s', '%s', '%s')
        );
        
        if ($result === false) {
            throw new Exception('Database error while saving API key.');
        }
        
        update_option('wp_management_api_key', $api_key);
        wp_send_json_success('API key verified and saved successfully.');
        
    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}