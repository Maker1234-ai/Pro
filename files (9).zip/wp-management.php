<?php
/**
 * Plugin Name: WP Management
 * Plugin URI: https://jtech.com/wp-management
 * Description: A comprehensive WordPress plugin for job management with duplication features and API key management.
 * Version: 1.0.0
 * Author: J Tech
 * Author URI: https://jtech.com
 * Text Domain: wp-management
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_MANAGEMENT_VERSION', '1.0.0');
define('WP_MANAGEMENT_PATH', plugin_dir_path(__FILE__));
define('WP_MANAGEMENT_URL', plugin_dir_url(__FILE__));
define('WP_MANAGEMENT_DEFAULT_API_KEY', 'HindiEnglish@1234');

// Initialize the plugin
function wp_management_init() {
    require_once WP_MANAGEMENT_PATH . 'includes/class-job-duplicator.php';
    new WP_Management_Job_Duplicator();
}
add_action('plugins_loaded', 'wp_management_init');

// Add admin menu
function wp_management_admin_menu() {
    add_menu_page(
        'WP Management',
        'WP Management',
        'manage_options',
        'wp-management',
        'wp_management_job_duplicator_page',
        'dashicons-admin-tools',
        30
    );
}
add_action('admin_menu', 'wp_management_admin_menu');

// Create tables on activation
function wp_management_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wp_management_jobs (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        original_job_id bigint(20) NOT NULL,
        new_job_id bigint(20) NOT NULL,
        location varchar(255) NOT NULL,
        created_by varchar(255) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'wp_management_activate');

// Enqueue admin scripts and styles
function wp_management_admin_enqueue_scripts($hook) {
    if (strpos($hook, 'wp-management') !== false) {
        wp_enqueue_style('wp-management-admin', WP_MANAGEMENT_URL . 'assets/css/admin.css', array(), WP_MANAGEMENT_VERSION);
        wp_enqueue_script('wp-management-admin', WP_MANAGEMENT_URL . 'assets/js/admin.js', array('jquery'), WP_MANAGEMENT_VERSION, true);
        wp_localize_script('wp-management-admin', 'wpManagement', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp_management_nonce')
        ));
    }
}
add_action('admin_enqueue_scripts', 'wp_management_admin_enqueue_scripts');