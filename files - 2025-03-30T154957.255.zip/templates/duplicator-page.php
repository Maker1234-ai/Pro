<div class="wrap wp-management-wrap">
    <div class="wp-management-header">
        <h1>Job Duplicator</h1>
    </div>
    
    <div class="wp-management-form">
        <div class="form-group">
            <label for="job-id">Select Job</label>
            <?php
            $args = array(
                'post_type' => 'job_listing',
                'posts_per_page' => -1
            );
            $jobs = get_posts($args);
            ?>
            <select id="job-id" name="job_id" required>
                <option value="">Select a job</option>
                <?php foreach ($jobs as $job): ?>
                    <option value="<?php echo esc_attr($job->ID); ?>">
                        <?php echo esc_html($job->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="company-id">Select Company (Optional)</label>
            <?php
            $args = array(
                'post_type' => 'company',
                'posts_per_page' => -1
            );
            $companies = get_posts($args);
            ?>
            <select id="company-id" name="company_id">
                <option value="">Keep original company</option>
                <?php foreach ($companies as $company): ?>
                    <option value="<?php echo esc_attr($company->ID); ?>">
                        <?php echo esc_html($company->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="locations">Locations (comma-separated)</label>
            <textarea id="locations" name="locations" rows="4" required></textarea>
        </div>

        <button id="duplicate-jobs" class="wp-management-button">Duplicate Jobs</button>

        <div class="wp-management-progress">
            <div class="wp-management-progress-bar"></div>
        </div>
    </div>
</div>