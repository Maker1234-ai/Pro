<?php
/**
 * The core plugin class.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The core plugin class.
 */
class PostRocket {

    /**
     * The loader that's responsible for maintaining and registering all hooks.
     *
     * @since    1.0.0
     * @access   protected
     * @var      PostRocket_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        /**
         * The class responsible for orchestrating the actions and filters of the core plugin.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-loader.php';

        /**
         * The class responsible for defining all actions in the admin area.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-admin.php';

        /**
         * The class responsible for handling job duplication.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-job-duplicator.php';

        /**
         * The class responsible for API functionality.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-api.php';

        /**
         * The class responsible for bulk management functionality.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-bulk-manager.php';

        /**
         * The class responsible for location management functionality.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-location-manager.php';

        /**
         * The class responsible for public-facing functionality.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-public.php';

        /**
         * The class responsible for handling AJAX requests.
         */
        require_once POSTROCKET_PLUGIN_DIR . 'includes/class-postrocket-ajax.php';

        $this->loader = new PostRocket_Loader();
    }

    /**
     * Register all of the hooks related to the admin area functionality of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new PostRocket_Admin();

        // Add admin menu items
        $this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );

        // Enqueue admin styles and scripts
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        
        // Add body class for hiding admin notices
        $this->loader->add_filter( 'admin_body_class', $plugin_admin, 'add_admin_body_class' );

        // Register AJAX handlers
        $this->loader->add_action( 'wp_ajax_postrocket_duplicate_jobs', $plugin_admin, 'ajax_duplicate_jobs' );
        $this->loader->add_action( 'wp_ajax_postrocket_save_settings', $plugin_admin, 'ajax_save_settings' );
        $this->loader->add_action( 'wp_ajax_postrocket_save_api_key', $plugin_admin, 'ajax_save_api_key' );
        $this->loader->add_action( 'wp_ajax_postrocket_verify_api_key', $plugin_admin, 'ajax_verify_api_key' );
        $this->loader->add_action( 'wp_ajax_postrocket_delete_duplicate_jobs', $plugin_admin, 'ajax_delete_duplicate_jobs' );
        $this->loader->add_action( 'wp_ajax_postrocket_delete_expired_jobs', $plugin_admin, 'ajax_delete_expired_jobs' );
        $this->loader->add_action( 'wp_ajax_postrocket_delete_all_jobs', $plugin_admin, 'ajax_delete_all_jobs' );
        $this->loader->add_action( 'wp_ajax_postrocket_save_location_list', $plugin_admin, 'ajax_save_location_list' );
        $this->loader->add_action( 'wp_ajax_postrocket_delete_location_list', $plugin_admin, 'ajax_delete_location_list' );
        
        // Register AJAX class hooks
        $plugin_ajax = new PostRocket_AJAX();
        $this->loader->add_action( 'init', $plugin_ajax, 'register_hooks' );
    }
    
    /**
     * Register all of the hooks related to the public-facing functionality of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $plugin_public = new PostRocket_Public();
        
        // No need to manually add hooks here as they are defined in the PostRocket_Public class constructor
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }
}
