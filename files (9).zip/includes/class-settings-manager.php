<?php
if (!defined('ABSPATH')) {
    exit;
}

class WP_Management_Settings_Manager {
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    public function register_settings() {
        register_setting('wp_management_settings', 'wp_management_max_jobs_per_minute');
        register_setting('wp_management_settings', 'wp_management_crawling_delay');
    }
    
    public function render_page() {
        try {
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            
            $max_jobs = get_option('wp_management_max_jobs_per_minute', 1000);
            $crawling_delay = get_option('wp_management_crawling_delay', 0);
            
            // Check if template exists before including
            $template_path = WP_MANAGEMENT_PATH . 'templates/settings.php';
            if (!file_exists($template_path)) {
                throw new Exception('Template file not found: settings.php');
            }
            
            // Buffer the output to catch any errors
            ob_start();
            include $template_path;
            $output = ob_get_clean();
            
            if (empty($output)) {
                throw new Exception('No content generated from template');
            }
            
            echo $output;
            
        } catch (Exception $e) {
            echo '<div class="error"><p>Error loading Settings page: ' . esc_html($e->getMessage()) . '</p></div>';
            error_log('WP Management Plugin Error: ' . $e->getMessage());
        }
    }
}