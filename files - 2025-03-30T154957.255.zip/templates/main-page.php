<div class="wrap wp-management-wrap">
    <div class="wp-management-header">
        <h1>WP Management</h1>
        <p>Author: <a href="#">J tech</a> | <a href="#">Visit Plugin</a></p>
    </div>
    
    <div class="wp-management-content">
        <h2>Welcome to WP Management</h2>
        <p>This plugin provides tools for job duplication and management with API integration.</p>
        
        <div class="wp-management-features">
            <h3>Features:</h3>
            <ul>
                <li>Job duplication with location management</li>
                <li>API key verification system</li>
                <li>Integration with WP Job Manager</li>
                <li>Company selection from MAS Companies</li>
                <li>Bulk location processing</li>
            </ul>
        </div>
    </div>
</div>