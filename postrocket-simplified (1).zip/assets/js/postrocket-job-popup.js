/**
 * JavaScript for job duplication popup functionality
 */
jQuery(document).ready(function($) {
    // Function to create and show the job duplication popup
    window.showJobDuplicationPopup = function(title, message, jobs) {
        // Create popup HTML
        var popupHtml = '<div class="postrocket-popup-overlay">' +
            '<div class="postrocket-popup-container">' +
            '<span class="postrocket-popup-close dashicons dashicons-no-alt"></span>' +
            '<div class="postrocket-popup-title">' + title + '</div>' +
            '<div class="postrocket-popup-content">' + message + '</div>';
        
        // Add job list if available
        if (jobs && jobs.length > 0) {
            popupHtml += '<div class="postrocket-job-list">';
            
            // Add each job to the list
            $.each(jobs, function(index, job) {
                popupHtml += '<div class="postrocket-job-list-item">' +
                    '<div class="postrocket-job-list-item-title">' + job.title + '</div>' +
                    '<div class="postrocket-job-list-item-action">' +
                    '<a href="' + job.edit_url + '" target="_blank">Edit</a> | ' +
                    '<a href="' + job.view_url + '" target="_blank">View</a>' +
                    '</div>' +
                    '</div>';
            });
            
            popupHtml += '</div>';
        }
        
        // Add action buttons
        popupHtml += '<div class="postrocket-popup-actions">';
        
        // Add "View All Jobs" button if we have jobs
        if (jobs && jobs.length > 0) {
            popupHtml += '<a href="' + postrocket_ajax.admin_url + 'edit.php?post_type=job_listing" class="postrocket-popup-button">View All Jobs</a>';
        }
        
        // Add close button
        popupHtml += '<button class="postrocket-popup-button secondary postrocket-popup-close-btn">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>';
        
        // Append popup to body
        $('body').append(popupHtml);
        
        // Handle close button click
        $('.postrocket-popup-close, .postrocket-popup-close-btn').on('click', function() {
            $('.postrocket-popup-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        // Show popup with animation
        $('.postrocket-popup-overlay').hide().fadeIn(300);
    }
    
    // Override the job duplicator form submission to show popup after success
    $('#postrocket-job-duplicator-form').off('submit').on('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        var jobId = $('#job_id').val();
        var mode = $('input[name="job-duplicator-mode"]:checked').val() || 'manual';
        var locations = '';
        
        // Check for job ID
        if (!jobId) {
            showNotification('Please select a job.', 'error');
            return false;
        }
        
        // Get locations based on mode
        if (mode === 'manual') {
            locations = $('#locations').val();
            if (!locations) {
                showNotification('Please enter at least one location.', 'error');
                return false;
            }
        } else {
            // Auto mode - check if location list is selected
            var locationListKey = $('#location_list_key').val();
            if (!locationListKey || locationListKey.length === 0) {
                showNotification('Please select at least one location list.', 'error');
                return false;
            }
        }
        
        // Show loading animation
        $('#postrocket-loading-container').show();
        $('#postrocket-loading-text').text('Starting job duplication...');
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Processing...');
        
        // Prepare data
        var formData = {
            action: 'postrocket_duplicate_jobs',
            nonce: postrocket_ajax.nonce,
            job_id: jobId,
            company_id: $('#company_id').val() || 0,
            mode: mode
        };
        
        // Add locations or location list key based on mode
        if (mode === 'manual') {
            formData.locations = locations;
        } else {
            formData.location_list_key = locationListKey;
        }
        
        // Send AJAX request
        $.ajax({
            url: postrocket_ajax.ajax_url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                if (response.success) {
                    // Show success message in notification area
                    showNotification(response.data.message, 'success');
                    
                    // Show popup with job details
                    console.log('AJAX Response:', response.data);
                    
                    if (response.data.jobs && response.data.jobs.length > 0) {
                        window.showJobDuplicationPopup(
                            'Job Duplication Successful',
                            'The job has been successfully duplicated to ' + response.data.jobs.length + ' locations.',
                            response.data.jobs
                        );
                    } else {
                        console.error('No job data available in the response');
                    }
                    
                    // Reset form
                    if (mode === 'manual') {
                        $('#locations').val('');
                        $('#locations-counter').text('0');
                    }
                } else {
                    // Show error message
                    showNotification(response.data.message, 'error');
                }
            },
            error: function() {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                // Show error message
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // Function to show notifications within the plugin UI (copied from original)
    function showNotification(message, type) {
        var notificationClass = 'postrocket-notification-' + type;
        var notification = '<div class="postrocket-notification ' + notificationClass + '">' + message + '</div>';
        
        // Add notification to the notification area
        $('#postrocket-notifications').html(notification);
        
        // Scroll to notification
        $('html, body').animate({
            scrollTop: $('#postrocket-notifications').offset().top - 50
        }, 500);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $('#postrocket-notifications').find('.postrocket-notification').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    }
});
