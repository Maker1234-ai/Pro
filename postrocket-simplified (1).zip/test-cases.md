# Test Cases for PostRocket Plugin

## 1. Plugin Icon Display
- [ ] Verify rocket icon appears in WordPress admin menu
- [ ] Verify rocket icon appears in plugin headers
- [ ] Verify icon displays correctly at different screen sizes

## 2. Job Duplicator Interface
- [ ] Verify radio buttons for mode selection work correctly
- [ ] Verify Manual Mode shows location text field
- [ ] Verify Auto Mode shows location list dropdown
- [ ] Verify location counter shows "X/50 locations" format
- [ ] Verify error message appears when exceeding 50 locations
- [ ] Verify validation prevents submitting more than 50 locations
- [ ] Verify notifications appear within plugin UI (not as admin notices)

## 3. Theme Feature Removal
- [ ] Verify theme toggle button is completely removed
- [ ] Verify no dark theme CSS remains in the stylesheet
- [ ] Verify light theme is consistently applied throughout

## 4. Location Manager Limits
- [ ] Verify location counter shows "X/50 locations" format
- [ ] Verify warning appears when approaching/exceeding limit
- [ ] Verify frontend validation prevents adding more than 50 locations
- [ ] Verify backend validation enforces 50 location limit
- [ ] Verify error messages display within plugin UI

## 5. API Key Popup Enhancement
- [ ] Verify popup appears with both "Add API Key Now" and "Later" buttons
- [ ] Verify "Later" button closes popup
- [ ] Verify popup only appears once per session
- [ ] Verify warning bar appears when API key is missing
- [ ] Verify plugin functionality is disabled without API key
- [ ] Verify "Add Key" button in warning bar works correctly

## 6. General UI Consistency
- [ ] Verify all buttons have consistent styling
- [ ] Verify all notifications appear within plugin UI
- [ ] Verify help text and tooltips are updated with new information
- [ ] Verify responsive design works on different screen sizes
