<?php
/**
 * The location manager functionality of the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The location manager functionality of the plugin.
 */
class PostRocket_Location_Manager {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
    }

    /**
     * Save a location list.
     *
     * @since    1.0.0
     * @param    string   $name       The name of the location list.
     * @param    string   $locations  Comma-separated list of locations.
     * @return   array|WP_Error       Success message or WP_Error on failure.
     */
    public function save_location_list( $name, $locations ) {
        if ( empty( $name ) ) {
            return new WP_Error( 'invalid_name', __( 'Please provide a name for the location list.', 'postrocket' ) );
        }
        
        if ( empty( $locations ) ) {
            return new WP_Error( 'invalid_locations', __( 'Please provide at least one location.', 'postrocket' ) );
        }

        // Parse locations
        $location_array = array_map( 'trim', explode( ',', $locations ) );
        $location_array = array_filter( $location_array );
        $location_array = array_unique( $location_array );

        if ( empty( $location_array ) ) {
            return new WP_Error( 'no_locations', __( 'No valid locations provided.', 'postrocket' ) );
        }
        
        // Check if location count exceeds limit
        if ( count( $location_array ) > 50 ) {
            return new WP_Error( 'too_many_locations', __( 'You cannot add more than 50 locations to a single list.', 'postrocket' ) );
        }

        // Get existing location lists
        $saved_locations = get_option( 'postrocket_saved_locations', array() );
        
        // Create a unique key for this list
        $key = sanitize_title( $name );
        
        // Check if key already exists
        $counter = 1;
        $original_key = $key;
        while ( isset( $saved_locations[$key] ) ) {
            $key = $original_key . '-' . $counter;
            $counter++;
        }
        
        // Add new location list
        $saved_locations[$key] = array(
            'name'      => sanitize_text_field( $name ),
            'locations' => $location_array,
            'created'   => current_time( 'mysql' ),
        );
        
        // Save to database
        update_option( 'postrocket_saved_locations', $saved_locations );
        
        return array(
            'message' => __( 'Location list saved successfully.', 'postrocket' ),
            'key'     => $key,
            'list'    => $saved_locations[$key],
        );
    }

    /**
     * Delete a location list.
     *
     * @since    1.0.0
     * @param    string   $key        The key of the location list to delete.
     * @return   array|WP_Error       Success message or WP_Error on failure.
     */
    public function delete_location_list( $key ) {
        if ( empty( $key ) ) {
            return new WP_Error( 'invalid_key', __( 'Invalid location list key.', 'postrocket' ) );
        }
        
        // Get existing location lists
        $saved_locations = get_option( 'postrocket_saved_locations', array() );
        
        // Check if key exists
        if ( ! isset( $saved_locations[$key] ) ) {
            return new WP_Error( 'not_found', __( 'Location list not found.', 'postrocket' ) );
        }
        
        // Store name for message
        $name = $saved_locations[$key]['name'];
        
        // Remove location list
        unset( $saved_locations[$key] );
        
        // Save to database
        update_option( 'postrocket_saved_locations', $saved_locations );
        
        return array(
            'message' => sprintf( __( 'Location list "%s" deleted successfully.', 'postrocket' ), $name ),
        );
    }

    /**
     * Get all location lists.
     *
     * @since    1.0.0
     * @return   array    Array of location lists.
     */
    public function get_location_lists() {
        return get_option( 'postrocket_saved_locations', array() );
    }

    /**
     * Get a specific location list.
     *
     * @since    1.0.0
     * @param    string   $key    The key of the location list.
     * @return   array|false      The location list or false if not found.
     */
    public function get_location_list( $key ) {
        $saved_locations = get_option( 'postrocket_saved_locations', array() );
        
        if ( isset( $saved_locations[$key] ) ) {
            return $saved_locations[$key];
        }
        
        return false;
    }

    /**
     * Get all locations from all lists.
     *
     * @since    1.0.0
     * @return   array    Array of unique locations.
     */
    public function get_all_locations() {
        $saved_locations = get_option( 'postrocket_saved_locations', array() );
        $all_locations = array();
        
        foreach ( $saved_locations as $list ) {
            $all_locations = array_merge( $all_locations, $list['locations'] );
        }
        
        return array_unique( $all_locations );
    }
}
