<?php
/**
 * Plugin Name: WP Management
 * Plugin URI: 
 * Description: A WordPress plugin for job duplication and management with API integration
 * Version: 1.0.0
 * Author: J tech
 * Author URI: 
 * Text Domain: wp-management
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_MANAGEMENT_VERSION', '1.0.0');
define('WP_MANAGEMENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_MANAGEMENT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Initialize the plugin
class WP_Management {
    private static $instance = null;
    private $api_key = 'HindiEnglish@1234';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_duplicate_jobs', array($this, 'duplicate_jobs'));
        add_action('wp_ajax_verify_api_key', array($this, 'verify_api_key'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'WP Management',
            'WP Management',
            'manage_options',
            'wp-management',
            array($this, 'main_page'),
            'dashicons-admin-generic',
            30
        );

        add_submenu_page(
            'wp-management',
            'Job Duplicator',
            'Job Duplicator',
            'manage_options',
            'wp-management-duplicator',
            array($this, 'duplicator_page')
        );

        add_submenu_page(
            'wp-management',
            'API Key',
            'API Key',
            'manage_options',
            'wp-management-api',
            array($this, 'api_page')
        );

        add_submenu_page(
            'wp-management',
            'Settings',
            'Settings',
            'manage_options',
            'wp-management-settings',
            array($this, 'settings_page')
        );
    }

    public function enqueue_admin_scripts() {
        wp_enqueue_style('wp-management-admin', WP_MANAGEMENT_PLUGIN_URL . 'assets/css/admin.css');
        wp_enqueue_script('wp-management-admin', WP_MANAGEMENT_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WP_MANAGEMENT_VERSION, true);
        wp_localize_script('wp-management-admin', 'wpManagement', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wp-management-nonce')
        ));
    }

    public function verify_api_key() {
        check_ajax_referer('wp-management-nonce', 'nonce');
        
        $submitted_key = sanitize_text_field($_POST['api_key']);
        $is_valid = ($submitted_key === $this->api_key);
        
        if ($is_valid) {
            update_option('wp_management_api_key', $submitted_key);
            wp_send_json_success('API key verified successfully');
        } else {
            wp_send_json_error('Invalid API key');
        }
    }

    public function duplicate_jobs() {
        check_ajax_referer('wp-management-nonce', 'nonce');
        
        if (!$this->is_api_valid()) {
            wp_send_json_error('Invalid API key');
            return;
        }

        $job_id = intval($_POST['job_id']);
        $company_id = intval($_POST['company_id']);
        $locations = array_map('trim', explode(',', sanitize_text_field($_POST['locations'])));
        
        $results = array();
        
        foreach ($locations as $location) {
            $new_job_id = $this->duplicate_single_job($job_id, $company_id, $location);
            if ($new_job_id) {
                $results[] = array(
                    'location' => $location,
                    'job_id' => $new_job_id
                );
            }
        }
        
        wp_send_json_success($results);
    }

    private function duplicate_single_job($job_id, $company_id, $location) {
        // Get original job post
        $job = get_post($job_id);
        if (!$job) return false;

        // Create new job post
        $new_job = array(
            'post_title' => $job->post_title . ' - ' . $location,
            'post_content' => $job->post_content,
            'post_status' => 'publish',
            'post_type' => 'job_listing',
            'post_author' => $job->post_author
        );

        // Insert the new job
        $new_job_id = wp_insert_post($new_job);

        if ($new_job_id) {
            // Copy job meta
            $meta_keys = get_post_custom_keys($job_id);
            foreach ($meta_keys as $meta_key) {
                $meta_values = get_post_meta($job_id, $meta_key, true);
                if ($meta_key === '_job_location') {
                    update_post_meta($new_job_id, $meta_key, $location);
                } else {
                    update_post_meta($new_job_id, $meta_key, $meta_values);
                }
            }

            // Update company if provided
            if ($company_id) {
                update_post_meta($new_job_id, '_company_id', $company_id);
            }

            // Copy taxonomies
            $taxonomies = get_object_taxonomies('job_listing');
            foreach ($taxonomies as $taxonomy) {
                $terms = wp_get_object_terms($job_id, $taxonomy, array('fields' => 'ids'));
                wp_set_object_terms($new_job_id, $terms, $taxonomy);
            }
        }

        return $new_job_id;
    }

    private function is_api_valid() {
        return get_option('wp_management_api_key') === $this->api_key;
    }

    // Admin page templates
    public function main_page() {
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/main-page.php';
    }

    public function duplicator_page() {
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/duplicator-page.php';
    }

    public function api_page() {
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/api-page.php';
    }

    public function settings_page() {
        include WP_MANAGEMENT_PLUGIN_DIR . 'templates/settings-page.php';
    }
}

// Initialize the plugin
function wp_management_init() {
    return WP_Management::get_instance();
}

add_action('plugins_loaded', 'wp_management_init');