<?php
/**
 * Provide a admin area view for the plugin job manager page.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Get job duplicator instance
$job_duplicator = new PostRocket_Job_Duplicator();

// Get API instance
$api = new PostRocket_API();

// Get jobs for dropdown
$jobs = $job_duplicator->get_jobs_for_dropdown();

// Get companies for dropdown
$companies = $job_duplicator->get_companies_for_dropdown();

// Get settings
$hide_duplicates = get_option( 'postrocket_hide_duplicates', 'no' );
$noindex_duplicates = get_option( 'postrocket_noindex_duplicates', 'no' );

// Get API key status
$api_key = $api->get_api_key();
$api_key_status = $api->validate_api_key();

// Get active tab
$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'job-duplicator';
?>

<div class="wrap postrocket-admin">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    
    
    <h2 class="nav-tab-wrapper">
        <a href="?page=postrocket-job-manager&tab=job-duplicator" class="nav-tab nav-tab-active">
            <?php esc_html_e( 'Job Duplicator', 'postrocket' ); ?>
        </a>
        <a href="?page=postrocket-job-manager&tab=api-settings" class="nav-tab <?php echo $active_tab === 'api-settings' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e( 'API Settings', 'postrocket' ); ?>
        </a>
    </h2>
    
    <div class="postrocket-tab-content">
        <?php if ( $active_tab === 'job-duplicator' ) : ?>
            <!-- Job Duplicator Tab -->
            <div class="postrocket-card">
                <div class="postrocket-card-header">
                    <h2><?php esc_html_e( 'Job Duplicator', 'postrocket' ); ?></h2>
                </div>
                <div class="postrocket-card-content">
                    <!-- Notification area for messages -->
                    <div id="postrocket-notifications"></div>
                    
                    <form id="postrocket-job-duplicator-form">
                        <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                        
                        <div class="postrocket-form-row">
                            <label for="job_id"><?php esc_html_e( 'Select Job', 'postrocket' ); ?></label>
                            <select id="job_id" name="job_id" required>
                                <option value=""><?php esc_html_e( 'Select a job', 'postrocket' ); ?></option>
                                <?php foreach ( $jobs as $job ) : ?>
                                    <option value="<?php echo esc_attr( $job['id'] ); ?>">
                                        <?php echo esc_html( $job['title'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php esc_html_e( 'Select the job you want to duplicate from the latest 2000 jobs.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <label for="company_id"><?php esc_html_e( 'Select Company (Optional)', 'postrocket' ); ?></label>
                            <select id="company_id" name="company_id">
                                <option value=""><?php esc_html_e( 'Use original company', 'postrocket' ); ?></option>
                                <?php foreach ( $companies as $company ) : ?>
                                    <option value="<?php echo esc_attr( $company['id'] ); ?>">
                                        <?php echo esc_html( $company['name'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <?php /* Mode Selection removed as requested */ ?>
                        
                        <div class="postrocket-form-row">
                            <label for="locations"><?php esc_html_e( 'Enter Locations (comma separated)', 'postrocket' ); ?></label>
                            <textarea id="locations" name="locations" rows="5" placeholder="<?php esc_attr_e( 'Enter locations (e.g., Bangalore, Hyderabad)', 'postrocket' ); ?>"></textarea>
                            <div class="postrocket-character-counter">
                                <span id="locations-counter">0</span>/50 locations
                            </div>
                            <p class="description">
                                <?php esc_html_e( 'Enter up to 50 locations separated by commas. Each location will create a duplicate of the selected job.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <div id="postrocket-loading-container" style="display: none;">
                                <div class="postrocket-loading-spinner"></div>
                                <div id="postrocket-loading-text">Processing...</div>
                            </div>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'Duplicate Jobs', 'postrocket' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
        <?php /* Visibility Settings removed as requested */ ?>
            
        <?php elseif ( $active_tab === 'api-settings' ) : ?>
            <!-- API Settings Tab -->
            <div class="postrocket-card">
                <div class="postrocket-card-header">
                    <h2><?php esc_html_e( 'API Settings', 'postrocket' ); ?></h2>
                </div>
                <div class="postrocket-card-content">
                    <form id="postrocket-api-settings-form">
                        <?php wp_nonce_field( 'postrocket_nonce', 'nonce' ); ?>
                        
                        <div class="postrocket-form-row">
                            <label for="api_key"><?php esc_html_e( 'API Key', 'postrocket' ); ?></label>
                            <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e( 'Enter your API key for PostRocket. The API key will be encrypted and tied to your domain for security. This key can only be used on one website.', 'postrocket' ); ?>
                            </p>
                        </div>
                        
                        <div class="postrocket-form-row">
                            <div class="postrocket-api-status">
                                <?php if ( $api_key_status ) : ?>
                                    <span class="postrocket-status-valid">
                                        <span class="dashicons dashicons-yes"></span>
                                        <?php esc_html_e( 'API Key is valid', 'postrocket' ); ?>
                                    </span>
                                <?php else : ?>
                                    <span class="postrocket-status-invalid">
                                        <span class="dashicons dashicons-no"></span>
                                        <?php esc_html_e( 'API Key is invalid or missing', 'postrocket' ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div id="postrocket-api-message"></div>
                        </div>
                        
                        <div class="postrocket-form-row postrocket-button-row">
                            <button type="submit" class="button button-primary">
                                <?php esc_html_e( 'Save API Key', 'postrocket' ); ?>
                            </button>
                            <button type="button" id="verify-api-key" class="button button-secondary">
                                <?php esc_html_e( 'Verify API Key', 'postrocket' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Container for popup notifications -->
    <div id="postrocket-popup-container"></div>
</div>

<!-- Direct popup implementation -->
<script type="text/javascript">
jQuery(document).ready(function($) {
    // Direct implementation of job duplication form submission
    $('#postrocket-job-duplicator-form').on('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        var jobId = $('#job_id').val();
        var locations = $('#locations').val();
        
        // Check for job ID
        if (!jobId) {
            alert('Please select a job.');
            return false;
        }
        
        // Check for locations
        if (!locations) {
            alert('Please enter at least one location.');
            return false;
        }
        
        // Show loading animation
        $('#postrocket-loading-container').show();
        
        // Disable submit button
        $(this).find('button[type="submit"]').prop('disabled', true).text('Processing...');
        
        // Prepare data
        var formData = {
            action: 'postrocket_duplicate_jobs',
            nonce: $('#postrocket-job-duplicator-form input[name="nonce"]').val(),
            job_id: jobId,
            company_id: $('#company_id').val() || 0,
            locations: locations
        };
        
        // Send AJAX request
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                if (response.success) {
                    // Show success message
                    $('#postrocket-notifications').html('<div class="notice notice-success"><p>' + response.data.message + '</p></div>');
                    
                    // Create and show popup
                    if (response.data.jobs && response.data.jobs.length > 0) {
                        showJobDuplicationPopup(response.data.jobs);
                    }
                    
                    // Reset form
                    $('#locations').val('');
                    $('#locations-counter').text('0');
                } else {
                    // Show error message
                    $('#postrocket-notifications').html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
                }
            },
            error: function() {
                // Hide loading animation
                $('#postrocket-loading-container').hide();
                
                // Re-enable submit button
                $('#postrocket-job-duplicator-form').find('button[type="submit"]').prop('disabled', false).text('Duplicate Jobs');
                
                // Show error message
                $('#postrocket-notifications').html('<div class="notice notice-error"><p>An error occurred. Please try again.</p></div>');
            }
        });
    });
    
    // Function to show job duplication popup
    function showJobDuplicationPopup(jobs) {
        // Create simple popup HTML
        var popupHtml = '<div class="postrocket-popup-overlay" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:99999; display:flex; justify-content:center; align-items:center;">' +
            '<div class="postrocket-popup-container" style="background:#fff; border-radius:5px; box-shadow:0 0 20px rgba(0,0,0,0.3); width:90%; max-width:400px; padding:20px; position:relative; text-align:center;">' +
            '<span class="postrocket-popup-close" style="position:absolute; top:10px; right:10px; font-size:20px; cursor:pointer; color:#666;" onclick="jQuery(\'.postrocket-popup-overlay\').remove();">×</span>' +
            '<div class="postrocket-popup-title" style="font-size:18px; font-weight:bold; margin-bottom:15px;">Job Duplicated Successfully</div>' +
            '<button class="button button-primary" style="margin-top:15px;" onclick="jQuery(\'.postrocket-popup-overlay\').remove();">OK</button>' +
            '</div>' +
            '</div>';
        
        // Append popup to body
        $('body').append(popupHtml);
    }
});
</script>
