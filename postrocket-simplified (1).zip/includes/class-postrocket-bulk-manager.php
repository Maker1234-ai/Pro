<?php
/**
 * The admin-specific functionality for bulk job management.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The admin-specific functionality for bulk job management.
 */
class PostRocket_Bulk_Manager {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
    }

    /**
     * Delete all duplicate jobs.
     *
     * @since    1.0.0
     * @return   int|WP_Error    Number of deleted jobs or WP_Error on failure.
     */
    public function delete_all_duplicate_jobs() {
        // Check if API key is valid
        $api = new PostRocket_API();
        if ( ! $api->validate_api_key() ) {
            return new WP_Error( 'invalid_api_key', __( 'Valid API key is required to use bulk management features.', 'postrocket' ) );
        }
        
        global $wpdb;
        
        // Get all duplicate job IDs
        $query = "
            SELECT p.ID
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'job_listing'
            AND pm.meta_key = '_postrocket_duplicated'
            AND pm.meta_value = '1'
        ";
        
        $job_ids = $wpdb->get_col( $query );
        
        if ( empty( $job_ids ) ) {
            return 0;
        }
        
        $count = 0;
        
        // Delete jobs in batches to prevent timeouts
        $batches = array_chunk( $job_ids, 50 );
        
        foreach ( $batches as $batch ) {
            foreach ( $batch as $job_id ) {
                if ( wp_delete_post( $job_id, true ) ) {
                    $count++;
                }
            }
            
            // Small delay to prevent server overload
            usleep( 100000 ); // 100ms delay
        }
        
        return $count;
    }
    
    /**
     * Delete all expired jobs.
     *
     * @since    1.0.0
     * @return   int|WP_Error    Number of deleted jobs or WP_Error on failure.
     */
    public function delete_all_expired_jobs() {
        // Check if API key is valid
        $api = new PostRocket_API();
        if ( ! $api->validate_api_key() ) {
            return new WP_Error( 'invalid_api_key', __( 'Valid API key is required to use bulk management features.', 'postrocket' ) );
        }
        
        global $wpdb;
        
        // Get all expired job IDs
        $query = "
            SELECT p.ID
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'job_listing'
            AND pm.meta_key = '_job_expires'
            AND pm.meta_value < %s
        ";
        
        $job_ids = $wpdb->get_col( $wpdb->prepare( $query, date( 'Y-m-d' ) ) );
        
        if ( empty( $job_ids ) ) {
            return 0;
        }
        
        $count = 0;
        
        // Delete jobs in batches to prevent timeouts
        $batches = array_chunk( $job_ids, 50 );
        
        foreach ( $batches as $batch ) {
            foreach ( $batch as $job_id ) {
                if ( wp_delete_post( $job_id, true ) ) {
                    $count++;
                }
            }
            
            // Small delay to prevent server overload
            usleep( 100000 ); // 100ms delay
        }
        
        return $count;
    }
    
    /**
     * Delete all jobs.
     *
     * @since    1.0.0
     * @return   int|WP_Error    Number of deleted jobs or WP_Error on failure.
     */
    public function delete_all_jobs() {
        // Check if API key is valid
        $api = new PostRocket_API();
        if ( ! $api->validate_api_key() ) {
            return new WP_Error( 'invalid_api_key', __( 'Valid API key is required to use bulk management features.', 'postrocket' ) );
        }
        
        global $wpdb;
        
        // Get all job IDs
        $query = "
            SELECT ID
            FROM {$wpdb->posts}
            WHERE post_type = 'job_listing'
        ";
        
        $job_ids = $wpdb->get_col( $query );
        
        if ( empty( $job_ids ) ) {
            return 0;
        }
        
        $count = 0;
        
        // Delete jobs in batches to prevent timeouts
        $batches = array_chunk( $job_ids, 50 );
        
        foreach ( $batches as $batch ) {
            foreach ( $batch as $job_id ) {
                if ( wp_delete_post( $job_id, true ) ) {
                    $count++;
                }
            }
            
            // Small delay to prevent server overload
            usleep( 100000 ); // 100ms delay
        }
        
        return $count;
    }
}
