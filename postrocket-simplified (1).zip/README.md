# PostRocket Job Duplicator for WP Job Manager

## Overview
This plugin extends the WP Job Manager plugin with enhanced job duplication capabilities, allowing you to quickly create multiple job listings across different locations while maintaining consistent job details.

## Features
1. **Job Duplication**: Duplicate job posts from WP Job Manager by entering a job ID or selecting from a dropdown
2. **Location-Based Titles**: Automatically adds location to job titles with a location counter
3. **Company Selection**: Choose a company from 'MAS Companies For WP Job Manager' or retain the original company
4. **Bulk Location Processing**: Enter up to 500 locations at once, separated by commas
5. **Visual Feedback**: Loading indicator shows progress during duplication
6. **Data Preservation**: Preserves all existing job details including categories, tags, salary, etc.

## Installation
1. Upload the plugin files to the `/wp-content/plugins/job-duplicator` directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to Job Manager > Job Duplicator to use the features

## Usage
1. Enter a job ID or select a job from the dropdown
2. Optionally select a company (if none selected, original company is retained)
3. Enter locations separated by commas (up to 500)
4. Click "Duplicate Jobs" to start the process
5. Wait for the process to complete (loading indicator will show progress)

## Requirements
- WordPress 5.0 or higher
- WP Job Manager plugin
- MAS Companies For WP Job Manager plugin (optional, for company selection)

## Changelog
### 1.0.0
- Initial release with job duplication features
- Support for up to 500 locations
- Location-based titles with counter
- Company selection integration

## Credits
Developed based on the PostRocket plugin framework
