<div class="wrap">
    <h1><?php echo esc_html__('API Key Management', 'wp-management'); ?></h1>
    
    <div class="wp-management-container">
        <form id="api-key-form" method="post">
            <?php wp_nonce_field('wp_management_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="api_key"><?php echo esc_html__('API Key', 'wp-management'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="api_key" 
                               name="api_key" 
                               value="<?php echo esc_attr($api_key); ?>" 
                               class="regular-text"
                               required>
                        <p class="description">
                            <?php echo esc_html__('Enter your API key. Default key is: HindiEnglish@1234', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <div class="submit-container">
                <button type="submit" class="button button-primary" id="verify-api-key">
                    <?php echo esc_html__('Verify API Key', 'wp-management'); ?>
                </button>
                <span class="spinner" style="float: none; margin-left: 10px;"></span>
            </div>
        </form>
        
        <div id="api-verification-result" style="margin-top: 20px;"></div>
    </div>
</div>

<style>
.wp-management-container {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.submit-container {
    margin-top: 20px;
}

.spinner {
    display: none;
}

.spinner.is-active {
    display: inline-block;
}
</style>

<script type="text/javascript">
jQuery(document).ready(function($) {
    $('#api-key-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $spinner = $form.find('.spinner');
        const $result = $('#api-verification-result');
        
        $spinner.addClass('is-active');
        $result.html('');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'verify_api_key',
                nonce: $('#_wpnonce').val(),
                api_key: $('#api_key').val()
            },
            success: function(response) {
                if (response.success) {
                    $result.html('<div class="notice notice-success"><p>' + response.data + '</p></div>');
                } else {
                    $result.html('<div class="notice notice-error"><p>' + response.data + '</p></div>');
                }
            },
            error: function() {
                $result.html('<div class="notice notice-error"><p>An error occurred while verifying the API key.</p></div>');
            },
            complete: function() {
                $spinner.removeClass('is-active');
            }
        });
    });
});
</script>