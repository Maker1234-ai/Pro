<div class="wrap">
    <h1><?php echo esc_html__('Job Duplicator', 'wp-management'); ?></h1>

    <div class="wp-management-container">
        <form id="job-duplicator-form">
            <?php wp_nonce_field('wp_management_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="job_id"><?php echo esc_html__('Select Job', 'wp-management'); ?></label>
                    </th>
                    <td>
                        <select name="job_id" id="job_id" required>
                            <option value=""><?php echo esc_html__('Select a job', 'wp-management'); ?></option>
                            <?php
                            $jobs = get_posts(array(
                                'post_type' => 'job_listing',
                                'posts_per_page' => -1,
                                'post_status' => 'publish'
                            ));

                            foreach ($jobs as $job) {
                                echo sprintf(
                                    '<option value="%d">%s</option>',
                                    esc_attr($job->ID),
                                    esc_html($job->post_title)
                                );
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="locations"><?php echo esc_html__('Locations', 'wp-management'); ?></label>
                    </th>
                    <td>
                        <textarea name="locations" id="locations" rows="5" cols="50" required
                                placeholder="<?php echo esc_attr__('Enter locations separated by commas (max 50)', 'wp-management'); ?>"></textarea>
                        <p class="description">
                            <?php echo esc_html__('Enter up to 50 locations, separated by commas', 'wp-management'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <div class="submit-container">
                <button type="submit" class="button button-primary">
                    <?php echo esc_html__('Duplicate Jobs', 'wp-management'); ?>
                </button>
                <span class="spinner"></span>
            </div>
        </form>

        <div id="duplication-results" class="duplication-results"></div>
    </div>
</div>

<style>
.wp-management-container {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.submit-container {
    margin-top: 20px;
}

.spinner {
    float: none;
    margin-left: 10px;
}

.duplication-results {
    margin-top: 20px;
}

.duplication-results .success {
    color: #46b450;
}

.duplication-results .error {
    color: #dc3232;
}
</style>