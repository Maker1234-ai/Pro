<?php
/**
 * The API functionality of the plugin.
 *
 * @since      1.0.0
 * @package    PostRocket
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The API functionality of the plugin.
 */
class PostRocket_API {

    /**
     * The encryption key.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $encryption_key    The encryption key.
     */
    private $encryption_key;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Generate encryption key based on site URL
        $this->encryption_key = md5( get_site_url() . 'postrocket_api_key' );
    }

    /**
     * Save API key with encryption.
     *
     * @since    1.0.0
     * @param    string    $api_key    The API key to save.
     * @return   bool|WP_Error         True on success, WP_Error on failure.
     */
    public function save_api_key( $api_key ) {
        if ( empty( $api_key ) ) {
            return new WP_Error( 'empty_api_key', __( 'API key cannot be empty.', 'postrocket' ) );
        }

        // Encrypt API key
        $encrypted_key = $this->encrypt( $api_key );
        
        if ( false === $encrypted_key ) {
            return new WP_Error( 'encryption_failed', __( 'Failed to encrypt API key.', 'postrocket' ) );
        }

        // Save encrypted key
        update_option( 'postrocket_api_key', $encrypted_key );
        
        return true;
    }

    /**
     * Get API key with decryption.
     *
     * @since    1.0.0
     * @return   string    The decrypted API key.
     */
    public function get_api_key() {
        $encrypted_key = get_option( 'postrocket_api_key', '' );
        
        if ( empty( $encrypted_key ) ) {
            return '';
        }

        // Decrypt API key
        $decrypted_key = $this->decrypt( $encrypted_key );
        
        if ( false === $decrypted_key ) {
            return '';
        }

        return $decrypted_key;
    }

    /**
     * Validate API key.
     *
     * @since    1.0.0
     * @return   bool    True if valid, false otherwise.
     */
    public function validate_api_key() {
        $api_key = $this->get_api_key();
        
        if ( empty( $api_key ) ) {
            return false;
        }

        // Check if API key matches the expected value
        return $api_key === 'SFBPY0F5VlZIQVlnem1Ocm1Yd3ZNOFhLMGpYQ2N';
    }
    
    /**
     * Verify API key and check domain restriction.
     *
     * @since    1.0.0
     * @return   array   Status and message.
     */
    public function verify_api_key() {
        $api_key = $this->get_api_key();
        
        if ( empty( $api_key ) ) {
            return array(
                'status'  => 'error',
                'message' => __( 'API key is missing.', 'postrocket' )
            );
        }

        // Check if API key matches the expected value
        if ( $api_key !== 'SFBPY0F5VlZIQVlnem1Ocm1Yd3ZNOFhLMGpYQ2N' ) {
            return array(
                'status'  => 'error',
                'message' => __( 'Invalid API key.', 'postrocket' )
            );
        }
        
        // Get current domain
        $current_domain = parse_url( get_site_url(), PHP_URL_HOST );
        
        // Check if this API key is registered to another domain
        $registered_domain = get_option( 'postrocket_api_domain', '' );
        
        if ( ! empty( $registered_domain ) && $registered_domain !== $current_domain ) {
            return array(
                'status'  => 'error',
                'message' => sprintf( 
                    __( 'This API key is already in use on %s. You must remove it from that website before using it here.', 'postrocket' ),
                    $registered_domain
                )
            );
        }
        
        // Register this domain with the API key if not already registered
        if ( empty( $registered_domain ) ) {
            update_option( 'postrocket_api_domain', $current_domain );
        }
        
        return array(
            'status'  => 'success',
            'message' => __( 'API key verified successfully.', 'postrocket' )
        );
    }

    /**
     * Encrypt data using AES-256-CBC.
     *
     * @since    1.0.0
     * @param    string    $data    The data to encrypt.
     * @return   string|false       Encrypted data or false on failure.
     */
    private function encrypt( $data ) {
        if ( ! extension_loaded( 'openssl' ) ) {
            return false;
        }

        $iv = openssl_random_pseudo_bytes( openssl_cipher_iv_length( 'aes-256-cbc' ) );
        $encrypted = openssl_encrypt( $data, 'aes-256-cbc', $this->encryption_key, 0, $iv );
        
        if ( false === $encrypted ) {
            return false;
        }

        return base64_encode( $iv . $encrypted );
    }

    /**
     * Decrypt data using AES-256-CBC.
     *
     * @since    1.0.0
     * @param    string    $data    The data to decrypt.
     * @return   string|false       Decrypted data or false on failure.
     */
    private function decrypt( $data ) {
        if ( ! extension_loaded( 'openssl' ) ) {
            return false;
        }

        $data = base64_decode( $data );
        $iv_length = openssl_cipher_iv_length( 'aes-256-cbc' );
        $iv = substr( $data, 0, $iv_length );
        $encrypted = substr( $data, $iv_length );
        
        return openssl_decrypt( $encrypted, 'aes-256-cbc', $this->encryption_key, 0, $iv );
    }

    /**
     * Make API request to DeepSeek API.
     *
     * @since    1.0.0
     * @param    string    $endpoint    The API endpoint.
     * @param    array     $data        The data to send.
     * @return   array|WP_Error         Response data or WP_Error on failure.
     */
    public function make_request( $endpoint, $data = array() ) {
        $api_key = $this->get_api_key();
        
        if ( empty( $api_key ) ) {
            return new WP_Error( 'missing_api_key', __( 'API key is missing.', 'postrocket' ) );
        }

        $url = 'https://api.deepseek.com/' . $endpoint;
        
        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body'    => json_encode( $data ),
            'timeout' => 30,
        );

        $response = wp_remote_post( $url, $args );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = wp_remote_retrieve_body( $response );
        $response_data = json_decode( $response_body, true );

        if ( $response_code !== 200 ) {
            $error_message = isset( $response_data['error'] ) ? $response_data['error'] : __( 'Unknown API error.', 'postrocket' );
            return new WP_Error( 'api_error', $error_message );
        }

        return $response_data;
    }
}
