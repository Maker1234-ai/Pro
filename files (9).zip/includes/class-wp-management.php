<?php
// Add this to the init() method of the WP_Management class

public function init() {
    // ... existing init code ...
    
    // Create tables on plugin initialization
    $this->create_tables();
}

private function create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = array();
    
    // Table for tracking duplicated jobs
    $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wp_management_job_tracking (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        original_job_id bigint(20) NOT NULL,
        new_job_id bigint(20) NOT NULL,
        location varchar(255) NOT NULL,
        company_id bigint(20),
        created_by varchar(255) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        status varchar(50) DEFAULT 'active',
        PRIMARY KEY  (id),
        KEY original_job_id (original_job_id),
        KEY new_job_id (new_job_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    foreach ($sql as $query) {
        dbDelta($query);
    }
}

// Add this method to render the main tracking page
public function render_main_page() {
    global $wpdb;
    
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    // Get total items for pagination
    $total_items = $wpdb->get_var("
        SELECT COUNT(*)
        FROM {$wpdb->prefix}wp_management_job_tracking
    ");
    
    // Get job tracking data
    $jobs = $wpdb->get_results($wpdb->prepare("
        SELECT jt.*, 
               oj.post_title as original_title,
               nj.post_title as new_title,
               c.post_title as company_name
        FROM {$wpdb->prefix}wp_management_job_tracking jt
        LEFT JOIN {$wpdb->posts} oj ON oj.ID = jt.original_job_id
        LEFT JOIN {$wpdb->posts} nj ON nj.ID = jt.new_job_id
        LEFT JOIN {$wpdb->posts} c ON c.ID = jt.company_id
        ORDER BY jt.created_at DESC
        LIMIT %d OFFSET %d
    ", $per_page, $offset));
    
    include WP_MANAGEMENT_PATH . 'templates/main-page.php';
}