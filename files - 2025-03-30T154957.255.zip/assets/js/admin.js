jQuery(document).ready(function($) {
    // API Key verification
    $('#verify-api-key').on('click', function(e) {
        e.preventDefault();
        var apiKey = $('#api-key').val();
        
        $.ajax({
            url: wpManagement.ajaxurl,
            type: 'POST',
            data: {
                action: 'verify_api_key',
                nonce: wpManagement.nonce,
                api_key: apiKey
            },
            beforeSend: function() {
                $('.wp-management-message').remove();
                $('#verify-api-key').prop('disabled', true).text('Verifying...');
            },
            success: function(response) {
                if (response.success) {
                    showMessage('success', 'API key verified successfully');
                } else {
                    showMessage('error', response.data);
                }
            },
            error: function() {
                showMessage('error', 'An error occurred while verifying the API key');
            },
            complete: function() {
                $('#verify-api-key').prop('disabled', false).text('Verify API Key');
            }
        });
    });

    // Job duplication
    $('#duplicate-jobs').on('click', function(e) {
        e.preventDefault();
        var jobId = $('#job-id').val();
        var companyId = $('#company-id').val();
        var locations = $('#locations').val();
        
        if (!jobId || !locations) {
            showMessage('error', 'Please fill in all required fields');
            return;
        }

        var locationsList = locations.split(',');
        var totalJobs = locationsList.length;
        var processedJobs = 0;

        $('.wp-management-progress').show();
        
        $.ajax({
            url: wpManagement.ajaxurl,
            type: 'POST',
            data: {
                action: 'duplicate_jobs',
                nonce: wpManagement.nonce,
                job_id: jobId,
                company_id: companyId,
                locations: locations
            },
            beforeSend: function() {
                $('.wp-management-message').remove();
                $('#duplicate-jobs').prop('disabled', true).text('Processing...');
                updateProgress(0);
            },
            success: function(response) {
                if (response.success) {
                    showMessage('success', 'Successfully duplicated ' + response.data.length + ' jobs');
                    updateProgress(100);
                } else {
                    showMessage('error', response.data);
                }
            },
            error: function() {
                showMessage('error', 'An error occurred while duplicating jobs');
            },
            complete: function() {
                $('#duplicate-jobs').prop('disabled', false).text('Duplicate Jobs');
            }
        });
    });

    function showMessage(type, message) {
        var messageHtml = '<div class="wp-management-message wp-management-' + type + '">' + message + '</div>';
        $('.wp-management-form').prepend(messageHtml);
    }

    function updateProgress(percentage) {
        $('.wp-management-progress-bar').css('width', percentage + '%');
    }
});