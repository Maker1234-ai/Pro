jQuery(document).ready(function($) {
    $('#job-duplicator-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submit = $form.find('button[type="submit"]');
        const $spinner = $form.find('.spinner');
        const $results = $('#duplication-results');
        
        $submit.prop('disabled', true);
        $spinner.addClass('is-active');
        $results.html('');
        
        $.ajax({
            url: wpManagement.ajaxurl,
            type: 'POST',
            data: {
                action: 'duplicate_jobs',
                nonce: $('#_wpnonce').val(),
                job_id: $('#job_id').val(),
                locations: $('#locations').val()
            },
            success: function(response) {
                if (response.success) {
                    let html = '<h3>Successfully duplicated jobs:</h3><ul>';
                    response.data.forEach(function(job) {
                        html += `<li class="success">New job created for location "${job.location}": ` +
                               `<a href="${job.url}" target="_blank">View Job</a></li>`;
                    });
                    html += '</ul>';
                    $results.html(html);
                } else {
                    $results.html(`<p class="error">${response.data}</p>`);
                }
            },
            error: function() {
                $results.html('<p class="error">An error occurred while duplicating jobs.</p>');
            },
            complete: function() {
                $submit.prop('disabled', false);
                $spinner.removeClass('is-active');
            }
        });
    });
});